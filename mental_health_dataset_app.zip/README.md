# Mental Health Dataset Creator

This app helps generate, filter, compare, and export prompt/response datasets for fine-tuning AI models in mental health.